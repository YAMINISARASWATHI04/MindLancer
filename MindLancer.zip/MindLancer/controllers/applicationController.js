// controllers/applicationController.js
const Application = require('../models/Application');

const applyForJob = async (req, res) => {
    try {
        const { name, email, resume, jobId, jobTitle } = req.body;

        const newApplication = new Application({
            name,
            email,
            resume,
            jobId,
            jobTitle
        });

        await newApplication.save();
        res.status(201).json({ message: 'Application submitted successfully' });
    } catch (err) {
        console.error('Error applying for job:', err);
        res.status(500).json({ message: 'Failed to submit application' });
    }
};

module.exports = {
    applyForJob
};
