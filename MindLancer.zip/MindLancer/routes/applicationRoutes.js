// routes/applicationRoutes.js
const express = require('express');
const router = express.Router();
const { applyForJob } = require('../controllers/applicationController');

router.post('/api/apply/jobs', applyForJob);

module.exports = router;
